<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $url string */
?>

<div class="chart">
    <?= Html::img($url) ?>
</div>