<?php

namespace app\modules\log;

class Module extends \yii\base\Module
{
    public $file = '@runtime/logs/app.log';
}