<?php

return [
    'components' => [
        'request' => [
            'cookieValidationKey' => '',
        ],
    ],
];
