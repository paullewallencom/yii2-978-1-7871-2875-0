<?php

return [
    'components' => [
        'request' => [
            'cookieValidationKey' => 'TRk9G1La5kvLFwqMEQTp6PmC1NHdjtkq',
        ],
    ],
];
