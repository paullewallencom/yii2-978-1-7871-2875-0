<?php

return [
    'adminEmail' => '',
];
