<?php

return [
    [
        'name' => 'Adolfo',
        'phone' => '127-013-7399',
        'city' => 'Lake Melvina',
        'about' => 'Perferendis amet ullam odio aliquam hic asperiores.',
        'password' => '$2y$13$Qx5mc99pPxIKW5rtLmIEzu4lzdFTU4VtD1AYSGLO8cJKMoJWVpDMO',
        'auth_key' => 'N_lU1t2LvsiVbrdsHI_xrHH-zVPEWO6f',
        'status' => 10,
    ],
    [
        'name' => 'Orville',
        'phone' => '886-412-7780x6494',
        'city' => 'Cristfurt',
        'about' => 'Qui sed et cum eos voluptas vel.',
        'password' => '$2y$13$uGwD7DBBIOxEZP050ot4gu4dQVpf74e5Y6A/UVIDUCKAfGhSMQeNO',
        'auth_key' => '7SmXDMzWSXbiWguVFzLQgzRVQLBkSkDt',
        'status' => 20,
    ],
];
